# plugins/github.py
from plugins.base import Plugin

class GithubPlugin(Plugin):
    def execute(self):
        print("Running GitHub plugin")

